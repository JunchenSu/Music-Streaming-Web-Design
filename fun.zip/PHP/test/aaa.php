<?php include_once "../external/SpotifyAPI.php";

echo SpotifyAPI::getToken();